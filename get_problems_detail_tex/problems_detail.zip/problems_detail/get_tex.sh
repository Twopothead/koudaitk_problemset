find . -name *.tex
